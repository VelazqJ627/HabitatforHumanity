(function($){
  $(function(){

    $(".button-collapse").sideNav();
    $('.parallax').parallax();
    $('.slider').slider({indicators: false});
    $('.modal-trigger').leanModal();

  }); // end of document ready
})(jQuery); // end of jQuery name space